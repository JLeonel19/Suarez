package Server;

public class Empleados_Enc {
    
    private int id_Emp2;
    private String Nombre_Emp2;
    private String ApePa_Emp2;
    private String ApeMa_Emp2;
    private String Rol_Emp2;
    private int Sueldo_Emp2;
    
    public Empleados_Enc() {
    }

    public Empleados_Enc(int id_Emp2, String Nombre_Emp2, String ApePa_Emp2, String ApeMa_Emp2, String Rol_Emp2, int Sueldo_Emp2) {
        this.id_Emp2 = id_Emp2;
        this.Nombre_Emp2 = Nombre_Emp2;
        this.ApePa_Emp2 = ApePa_Emp2;
        this.ApeMa_Emp2 = ApeMa_Emp2;
        this.Rol_Emp2 = Rol_Emp2;
        this.Sueldo_Emp2 = Sueldo_Emp2;
    }

    public int getId_Emp2() {
        return id_Emp2;
    }

    public void setId_Emp2(int id_Emp2) {
        this.id_Emp2 = id_Emp2;
    }

    public String getNombre_Emp2() {
        return Nombre_Emp2;
    }

    public void setNombre_Emp2(String Nombre_Emp2) {
        this.Nombre_Emp2 = Nombre_Emp2;
    }

    public String getApePa_Emp2() {
        return ApePa_Emp2;
    }

    public void setApePa_Emp2(String ApePa_Emp2) {
        this.ApePa_Emp2 = ApePa_Emp2;
    }

    public String getApeMa_Emp2() {
        return ApeMa_Emp2;
    }

    public void setApeMa_Emp2(String ApeMa_Emp2) {
        this.ApeMa_Emp2 = ApeMa_Emp2;
    }

    public String getRol_Emp2() {
        return Rol_Emp2;
    }

    public void setRol_Emp2(String Rol_Emp2) {
        this.Rol_Emp2 = Rol_Emp2;
    }

    public int getSueldo_Emp2() {
        return Sueldo_Emp2;
    }

    public void setSueldo_Emp2(int Sueldo_Emp2) {
        this.Sueldo_Emp2 = Sueldo_Emp2;
    }
}
