package Server;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Empleados_Met extends Conexion{
    
    Conexion cn = new Conexion();
    
    public List<Empleados_Enc> dis_listar() {
        List<Empleados_Enc> empleados = new ArrayList<>();
        try{
            Statement st = cn.con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM empleados");
            Empleados_Enc emp;
            while (rs.next()){
                emp = new Empleados_Enc(
                        Integer.parseInt(rs.getString(1)),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        Integer.parseInt(rs.getString(6))
                );
                empleados.add(emp); 
            }
            cn.con.close();
        }catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
        return empleados;
    }
    
    public boolean registrar(int id_Emp, String Nombre_Emp, String ApePa_Emp, String ApeMa_Emp, String Rol_Emp, int Sueldo_Emp ){
        boolean estado = false;
        try{
            Statement st = cn.con.createStatement();
            String Datos = "'" + id_Emp + "'";
            Datos = Datos + "'" + Nombre_Emp + "'";
            Datos = Datos + "'" + ApePa_Emp + "'";
            Datos = Datos + "'" + ApeMa_Emp + "'";
            Datos = Datos + "'" + Rol_Emp + "'";
            Datos = Datos + "'" + Sueldo_Emp + "'";
            int rs = st.executeUpdate("INSERT INTO empleados VALUES(" + Datos + ")");
            if (rs >=1){
                estado = true;
            }
            cn.con.close();
        }catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
        return estado;
    }
    
    public Empleados_Enc buscar(int id_Emp){
        Empleados_Enc cap = null;
        try{
            Statement st = cn.con.createStatement();
            ResultSet rs = st.executeQuery("Select * from empleados WHERE id_Emp"+ id_Emp);
            while(rs.next()){
                cap = new Empleados_Enc(
                        rs.getInt("id_Emp"),
                        rs.getString("Nombre_Emp"),
                        rs.getString("ApePa_Emp"),
                        rs.getString("ApeMa_Emp"),
                        rs.getString("Rol_Emp"),
                        rs.getInt("Sueldo_Emp")
                );  
            }
            cn.con.close();
        }catch(Exception e){
            System.out.println("Error al encontrar el empleado : " + e.getMessage());
        }
        return cap;
    }
    
    public boolean actualizar(int id_Emp, String Nombre_Emp, String ApePa_Emp, String ApeMa_Emp, String Rol_Emp, int Sueldo_Emp ){
        boolean estado = false;
        try{
            Statement st = cn.con.createStatement();
            int rs = st.executeUpdate("UPDATE empleados SET id_Emp='" + id_Emp + "', Nombre_Emp='" 
                                        + Nombre_Emp + "', ApePa_Emp='" + ApePa_Emp + "', ApeMa_Emp='" + ApeMa_Emp 
                                        + "', Rol_Emp='" + Rol_Emp + "', Sueldo_Emp='" + Sueldo_Emp);
            if (rs >=1){
                estado = true;
            }
            cn.con.close();
        }catch(Exception e){
            System.out.println("Error al actualizar los datos " + e.getMessage());
        }
        return estado;
    }
    
    public boolean eliminar(int id_Emp){
        boolean estado = false;
        try{
            Statement st = cn.con.createStatement();
            int rs = st.executeUpdate("DELETE FROM empleados WHERE id_Emple" + id_Emp);
             if (rs >=1){
                estado = true;
            }
            cn.con.close();
        }catch(Exception e){
            System.out.println("Error al eliminar:" + e.getMessage());
        }
        return estado;
    } 
}